create function lista()
  returns character varying
language plpgsql
as $$
DECLARE
  linhas VARCHAR;
  i RECORD;
BEGIN

  linhas := '';

  FOR i IN SELECT num FROM equipamento.controladora WHERE habilitado = 1 LOOP
    linhas := linhas || '"Contagem":' || i.num || ',"Itens":' || equipamento.info(i.num) || ',';
  END LOOP;
  RETURN '{' || substr(linhas, 1, char_length(linhas)-1) || '}';
END;
$$;

