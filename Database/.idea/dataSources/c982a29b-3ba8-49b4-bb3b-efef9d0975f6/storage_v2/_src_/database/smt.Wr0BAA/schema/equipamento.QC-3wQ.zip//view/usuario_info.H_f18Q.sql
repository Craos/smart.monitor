create view usuario_info as
  SELECT (to_char((moradores.filedate)::timestamp with time zone, 'DD/MM/YYYY'::text))::character varying AS filedate,
    moradores.num,
    unidades.bloco,
    unidades.unidade,
    moradores.autenticacao,
    (
        CASE
            WHEN ("position"((moradores.nome)::text, ' '::text) = 0) THEN initcap((moradores.nome)::text)
            ELSE initcap(substr((moradores.nome)::text, 1, "position"((moradores.nome)::text, ' '::text)))
        END)::character varying AS primeiro_nome,
    moradores.foto1,
    moradores.nascimento,
    idade(moradores.nascimento) AS idade,
    (parentesco(moradores.parentesco))::text AS parentesco,
    (genero((moradores.genero)::integer))::text AS genero
   FROM (condominio.unidades
     JOIN condominio.moradores ON ((unidades.num = moradores.unidade)));

