create view lista as
  SELECT r.lista
   FROM equipamento.listaweb() r(lista json);

