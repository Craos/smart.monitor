create function analise_tag(info json)
  returns character varying
language plpgsql
as $$
DECLARE
  registro RECORD;
  monitor  RECORD;
  at       VARCHAR;
BEGIN

  at := right((info ->> 'serial'), 6);

  SELECT
    INTO registro
    veiculos.num,
    unidades.condominio,
    unidades.bloco,
    unidades.andar,
    unidades.unidade,
    veiculos.autenticacao,
    veiculos.modelo,
    veiculos.placa_letras,
    veiculos.placa_numeros,
    veiculos.cor
  FROM condominio.veiculos
  JOIN condominio.unidades ON
       veiculos.condominio = unidades.condominio
   AND veiculos.bloco = unidades.bloco
   AND veiculos.andar = unidades.andar
   AND veiculos.unidade = unidades.num
 WHERE autenticacao = at;

  SELECT
    INTO monitor *
    FROM acesso.monitor_garagem
   WHERE autenticacao = at;

    IF registro.num IS NOT NULL THEN

      IF (info ->> 'sentido') = 'E' OR (info ->> 'sentido') = 'S' THEN
        IF monitor.autenticacao IS NULL
        THEN -- O veiculo ainda nao esta na tabela de fiscalizacao da garagem
          RAISE NOTICE 'Cadastrando a autenticacao no monitor de garagem';
          INSERT INTO acesso.monitor_garagem (autenticacao, bloco, unidade, situacao)
          VALUES (at, registro.bloco, registro.unidade, (info ->> 'sentido'));
        ELSE
          UPDATE acesso.monitor_garagem
             SET situacao = (info ->> 'sentido'), data = current_timestamp
           WHERE autenticacao = at;
          RAISE NOTICE 'O usuario encontra-se %', (info ->> 'sentido');
        END IF;
      END IF;


      INSERT
      INTO acesso.passagem_veiculo (
        condominio, bloco, andar, unidade, autenticacao, equipamento, localizacao_equipamento, leitor,
        localizacao_leitor, situacao_leitor, situacao_usuario, dsc_situacao, modelo,
        placa_letras, placa_numeros, cor, acesso_supervisionado
      )
    VALUES (
      registro.condominio,
      registro.bloco,
      registro.andar,
      registro.unidade,
      registro.autenticacao,
      (info ->> 'controladora')::INTEGER,
      (info ->> 'localizacao_equipamento'),
      (info ->> 'leitor')::INTEGER,
      (info ->> 'localizacao_leitor'),
      'Autorizado',
      'Autorizado',
      'Acesso autorizado',
      registro.modelo,
      registro.placa_letras,
      registro.placa_numeros,
      registro.cor,
      'ctrlwebsocket'
    );

    RETURN '{"situacao":true,"motivo":"localizado"}';
  ELSE
    INSERT
    INTO acesso.passagem_veiculo (
      condominio, bloco, andar, unidade, autenticacao, equipamento, localizacao_equipamento, leitor,
      localizacao_leitor, situacao_leitor, situacao_usuario, dsc_situacao, modelo,
      placa_letras, placa_numeros, cor, acesso_supervisionado
    )
    VALUES (
      1,
      0,
      0,
      0,
      (info ->> 'serial'),
      (info ->> 'controladora')::INTEGER,
      (info ->> 'localizacao_equipamento'),
      (info ->> 'leitor')::INTEGER,
      (info ->> 'localizacao_leitor'),
      'Acesso negado',
      'Acesso negado',
      'Acesso negado',
      'Não localizado',
      'Não localizado',
      '0000'::INTEGER,
      'Não localizado',
      'ctrlwebsocket'
    );
    RETURN '{"situacao":false,"motivo":"usuário não localizado"}';
  END IF;
END;
$$;

