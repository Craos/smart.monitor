create function analise_rfid(info json)
  returns character varying
language plpgsql
as $$
DECLARE
  registro RECORD;
BEGIN

  SELECT
    INTO registro
    moradores.num,
    unidades.condominio,
    unidades.bloco,
    unidades.andar,
    unidades.unidade,
    moradores.autenticacao,
    moradores.nome,
    moradores.nascimento,
    moradores.parentesco
  FROM condominio.moradores
    JOIN condominio.unidades ON
                               moradores.condominio = unidades.condominio
                               AND moradores.bloco = unidades.bloco
                               AND moradores.andar = unidades.andar
                               AND moradores.unidade = unidades.num
  WHERE autenticacao = right((info ->> 'serial'), 5);

  IF registro.num IS NOT NULL THEN
    INSERT
    INTO acesso.passagem_pedestre (
      condominio, bloco, andar, unidade, autenticacao, equipamento, localizacao_equipamento, leitor,
      localizacao_leitor, situacao_leitor, situacao_usuario, dsc_situacao, nome, tipo_de_cadastro, dispositivo
    )
    VALUES (
      registro.condominio,
      registro.bloco,
      registro.andar,
      registro.unidade,
      registro.autenticacao,
      (info ->> 'controladora')::INTEGER,
      (info ->> 'localizacao_equipamento'),
      (info ->> 'leitor')::INTEGER,
      (info ->> 'localizacao_leitor'),
      'Autorizado',
      'Autorizado',
      'Acesso autorizado',
      registro.nome,
      'morador',
      'ctrlwebsocket'
    );

    RETURN '{"situacao":true,"motivo":"localizado"}';
  ELSE
    INSERT
    INTO acesso.passagem_pedestre (
      condominio, bloco, andar, unidade, autenticacao, equipamento, localizacao_equipamento, leitor,
      localizacao_leitor, situacao_leitor, situacao_usuario, dsc_situacao, nome, tipo_de_cadastro, dispositivo
    )
    VALUES (
      1,
      0,
      0,
      0,
      (info ->> 'serial'),
      (info ->> 'controladora')::INTEGER,
      (info ->> 'localizacao_equipamento'),
      (info ->> 'leitor')::INTEGER,
      (info ->> 'localizacao_leitor'),
      'Acesso negado',
      'Acesso negado',
      'Acesso negado',
      'Não localizado',
      'Não localizado',
      'ctrlwebsocket'
    );
    RETURN '{"situacao":false,"motivo":"usuário não localizado"}';
  END IF;
END;
$$;

