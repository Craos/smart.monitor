create function listaweb()
  returns SETOF record
language plpgsql
as $$
DECLARE
    i RECORD;
  BEGIN
    FOR i IN SELECT num FROM equipamento.controladora LOOP
      RETURN QUERY
      select row_to_json(equipamento_info.*) AS controladora
      FROM (
             SELECT
               controladora.filedate,
               controladora.condominio,
               controladora.num,
               controladora.descricao,
               controladora.tipo_conexao,
               controladora.endereco,
               controladora.porta,
               (
                 SELECT array_to_json(array_agg(row_to_json(leitores.*))) AS array_to_json
                 FROM (
                        SELECT
                          leitor.filedate,
                          leitor.num,
                          leitor.controladora,
                          leitor.descricao,
                          leitor.porta,
                          leitor.procedimento,
                          leitor.sentido,
                          array_to_json(array_agg(row_to_json(acionador.*))) AS acionadores
                        FROM (equipamento.leitor
                          LEFT JOIN equipamento.acionador
                            ON (((leitor.controladora = acionador.controladora) AND (leitor.num = acionador.leitor))))
                        WHERE acionador.controladora = i.num
                        GROUP BY leitor.filedate, leitor.num, leitor.controladora, leitor.descricao, leitor.porta,
                          leitor.procedimento
                      ) leitores
               ) AS leitores
             FROM equipamento.controladora
           WHERE num = i.num
           ) equipamento_info;
    END LOOP;
  END;

$$;

