create view usuario_lista as
  SELECT moradores.num AS id,
    unidades.bloco,
    unidades.unidade,
    moradores.autenticacao,
    (
        CASE
            WHEN ("position"((moradores.nome)::text, ' '::text) = 0) THEN initcap((moradores.nome)::text)
            ELSE initcap(substr((moradores.nome)::text, 1, "position"((moradores.nome)::text, ' '::text)))
        END)::character varying AS nome,
    moradores.foto1 AS foto
   FROM (condominio.unidades
     JOIN condominio.moradores ON ((unidades.num = moradores.unidade)))
  ORDER BY char_length((moradores.foto1)::text);

