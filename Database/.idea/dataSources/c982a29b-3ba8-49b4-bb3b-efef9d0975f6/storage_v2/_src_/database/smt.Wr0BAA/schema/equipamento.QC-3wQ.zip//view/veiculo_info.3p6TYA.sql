create view veiculo_info as
  SELECT upper((veiculos.autenticacao)::text) AS autenticacao,
    unidades.bloco,
    unidades.unidade,
    initcap((veiculos.modelo)::text) AS modelo,
    ((upper((veiculos.placa_letras)::text) || '-'::text) || (veiculos.placa_numeros)::text) AS placa,
    initcap((veiculos.cor)::text) AS cor
   FROM (condominio.veiculos
     JOIN condominio.unidades ON (((((veiculos.condominio = unidades.condominio) AND (veiculos.bloco = unidades.bloco)) AND (veiculos.andar = unidades.andar)) AND (veiculos.unidade = unidades.num))));

