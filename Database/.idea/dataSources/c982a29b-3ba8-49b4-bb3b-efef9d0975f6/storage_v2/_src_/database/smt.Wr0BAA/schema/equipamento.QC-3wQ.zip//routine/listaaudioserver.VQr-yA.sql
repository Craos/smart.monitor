create function listaaudioserver()
  returns character varying
language plpgsql
as $$
BEGIN
  RETURN array_to_json(array_agg(row_to_json(equipamento_info)))
  FROM (
         SELECT
           *
         FROM equipamento.audiosystem
       ) AS equipamento_info;
END;
$$;

