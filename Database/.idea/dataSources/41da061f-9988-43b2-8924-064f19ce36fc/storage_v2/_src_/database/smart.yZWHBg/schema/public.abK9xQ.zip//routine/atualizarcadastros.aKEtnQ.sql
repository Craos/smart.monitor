create function atualizarcadastros(origem character varying, limite bigint)
  returns integer
language plpgsql
as $$
DECLARE
  totalregistros int;
  downloaditem   record;
  item           record;
  linhalimite int;
BEGIN

  totalregistros := 0;
  linhalimite := 0;

  -- Inicia a conexao com o banco de dados central
  PERFORM dblink_connect(origem);

  /* Inicio do procedimento de download */

  -- Remove as chaves de comparacao
  TRUNCATE TABLE chaves_veiculos;

  -- Cria uma tabela temporária para armazenar as matriculas
  INSERT INTO chaves_veiculos
  SELECT num
    FROM dblink($_$
         SELECT num
           FROM condominio.veiculos
          WHERE num notnull and autenticacao notnull
    $_$) AS t(num int);

  -- Compara e obtem as matriculas que ainda não existem na tabela
  FOR downloaditem IN
      SELECT chaves_veiculos.num
        FROM chaves_veiculos
        LEFT JOIN veiculos ON chaves_veiculos.num = veiculos.num
       WHERE veiculos.num ISNULL
  LOOP

    SELECT *
      INTO item
      FROM dblink($_$
      insert into veiculos (filedate, timerg, uidins, num, condominio, bloco, andar, unidade, autenticacao, vaga, vaga_locada, modelo, cor, descricao, foto, observacao, marca, placa_letras, placa_numeros, autenticacao_visual, bloqueio, portas, controle_porteiro, tipo_veiculo, situacao_estacionamento, lastdate, lasttime, lastuser, p1_data, p1_hora, p2_data, p2_hora, p4_data, p4_hora, proprietario, serial, new_num)
           select filedate, timerg, uidins, num, condominio, bloco, andar, unidade, autenticacao, vaga, vaga_locada, modelo, cor, descricao, foto, observacao, marca, placa_letras, placa_numeros, autenticacao_visual, bloqueio, portas, controle_porteiro, tipo_veiculo, situacao_estacionamento, lastdate, lasttime, lastuser, p1_data, p1_hora, p2_data, p2_hora, p4_data, p4_hora, proprietario, serial, new_num
             from condominio.veiculos
            where num notnull and autenticacao notnull and num = $_$ || downloaditem.num || $_$
           order by num desc
      $_$) AS r( filedate date, timerg time, uidins varchar, num serial, condominio integer, bloco integer, andar integer, unidade integer, autenticacao varchar,
           vaga integer, vaga_locada numeric, modelo varchar, cor varchar, descricao varchar, foto varchar, observacao varchar, marca varchar, placa_letras varchar,
           placa_numeros varchar, autenticacao_visual varchar, bloqueio numeric, portas character varying[], controle_porteiro integer, tipo_veiculo integer,
           situacao_estacionamento numeric, lastdate date, lasttime time, lastuser varchar, p1_data date, p1_hora time, p2_data date, p2_hora time, p4_data date,
           p4_hora time, proprietario varchar, serial varchar, new_num integer);

      IF (item.condominio NOTNULL) THEN
          raise notice '%', item.num;
          INSERT INTO veiculos (filedate, timerg, uidins, num, condominio, bloco, andar, unidade, autenticacao, vaga, vaga_locada, modelo, cor, descricao, foto, observacao, marca, placa_letras, placa_numeros, autenticacao_visual, bloqueio, portas, controle_porteiro, tipo_veiculo, situacao_estacionamento, lastdate, lasttime, lastuser, p1_data, p1_hora, p2_data, p2_hora, p4_data, p4_hora, proprietario, serial, new_num)
          VALUES (item.filedate, item.timerg, item.uidins, item.num, item.condominio, item.bloco, item.andar, item.unidade, item.autenticacao, item.vaga, item.vaga_locada, item.modelo, item.cor, item.descricao, item.foto, item.observacao, item.marca, item.placa_letras, item.placa_numeros, item.autenticacao_visual, item.bloqueio, item.portas, item.controle_porteiro, item.tipo_veiculo, item.situacao_estacionamento, item.lastdate, item.lasttime, item.lastuser, item.p1_data, item.p1_hora, item.p2_data, item.p2_hora, item.p4_data, item.p4_hora, item.proprietario, item.serial, item.new_num);
      ELSE
        RAISE NOTICE ' % Nao foi importado', downloaditem.num;
      END IF;

      EXIT WHEN linhalimite = limite;
      linhalimite = linhalimite + 1;

  END LOOP;

  /* Final do procedimento de download */

  /* Inicio do procedimento de limpeza dos registros que foram removidos no banco de dados central */

  DELETE
    FROM veiculos
   WHERE num in (
     SELECT veiculos.num as veiculo
       FROM chaves_veiculos
      RIGHT JOIN veiculos on chaves_veiculos.num = veiculos.num
      WHERE chaves_veiculos.num isnull
   );

  /* Final do procedimento de limpeza dos registros que foram removidos no banco de dados central */

  SELECT count(*)
    INTO totalregistros
    FROM veiculos;

  PERFORM dblink_disconnect();
  RETURN totalregistros;
END;
$$;

