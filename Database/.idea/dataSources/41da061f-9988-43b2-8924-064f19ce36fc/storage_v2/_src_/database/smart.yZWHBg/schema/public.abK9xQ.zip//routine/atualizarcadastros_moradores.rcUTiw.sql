create function atualizarcadastros_moradores(origem character varying, limite bigint)
  returns integer
language plpgsql
as $$
DECLARE
  totalregistros int;
  downloaditem   record;
  item           record;
  linhalimite int;
BEGIN

  totalregistros := 0;
  linhalimite := 0;

  -- Inicia a conexao com o banco de dados central
  PERFORM dblink_connect(origem);

  /* Inicio do procedimento de download */

  -- Remove as chaves de comparacao
  TRUNCATE TABLE chaves_moradores;

  -- Cria uma tabela temporária para armazenar as matriculas
  INSERT INTO chaves_moradores
  SELECT num
    FROM dblink($_$
         SELECT num
           FROM condominio.moradores
          WHERE num notnull and foto1 notnull and autenticacao notnull
    $_$) AS t(num int);

  -- Compara e obtem as matriculas que ainda não existem na tabela de pedestre
  FOR downloaditem IN
      SELECT chaves_moradores.num
        FROM chaves_moradores
        LEFT JOIN pedestre ON chaves_moradores.num = pedestre.num
       WHERE pedestre.num ISNULL
  LOOP

    SELECT *
      INTO item
      FROM dblink($_$
         select condominio, bloco, andar, unidade, bloqueio, num, foto1, autenticacao, nome, 'Morador' as tipo_de_cadastro, ativacao, substring(nascimento, 1, 10) as nascimento
           from condominio.moradores
           where num notnull and foto1 notnull and autenticacao notnull and num = $_$ || downloaditem.num || $_$
           order by num desc
      $_$) AS r( condominio integer, bloco integer, andar integer, unidade integer, bloqueio numeric, num integer, foto1 varchar, autenticacao varchar(10), nome varchar(400), tipo_de_cadastro varchar(50), ativacao timestamp, nascimento varchar(10));

      IF (item.condominio NOTNULL) THEN
          raise notice '%', item.num;
          INSERT INTO pedestre (condominio, bloco, andar, unidade, bloqueio, num, foto1, autenticacao, nome, tipo_de_cadastro, ativacao, nascimento)
          VALUES (item.condominio, item.bloco, item.andar, item.unidade, item.bloqueio, item.num, item.foto1, item.autenticacao, item.nome, item.tipo_de_cadastro, item.ativacao, item.nascimento);
      ELSE
        RAISE NOTICE ' % Nao foi importado', downloaditem.num;
      END IF;

      EXIT WHEN linhalimite = limite;
      linhalimite = linhalimite + 1;

  END LOOP;

  /* Final do procedimento de download */

  /* Inicio do procedimento de limpeza dos registros que foram removidos no banco de dados central */

  DELETE
    FROM pedestre
   WHERE num in (
     SELECT pedestre.num as pedestre
       FROM chaves_moradores
      RIGHT JOIN pedestre on chaves_moradores.num = pedestre.num
      WHERE chaves_moradores.num isnull
   );

  /* Final do procedimento de limpeza dos registros que foram removidos no banco de dados central */

  SELECT count(*)
    INTO totalregistros
    FROM pedestre;

  PERFORM dblink_disconnect();
  RETURN totalregistros;
END;
$$;

