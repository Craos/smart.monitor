CREATE RULE ignore_duplicate_inserts_on_t AS
    ON INSERT TO public.pedestre
   WHERE (EXISTS ( SELECT 1
           FROM pedestre
          WHERE ((pedestre.autenticacao)::text = (new.autenticacao)::text))) DO INSTEAD NOTHING;

