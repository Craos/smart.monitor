create function buscarveiculo(info json)
  returns SETOF json
language plpgsql
as $$
DECLARE
  veiculo RECORD;
  serialid varchar;
BEGIN

  serialid := RIGHT(upper((info->>'serial')), 6);

  SELECT veiculos.condominio, unidades.bloco, unidades.andar, unidades.unidade, autenticacao, bloqueio, modelo, placa_letras, placa_numeros, cor
    INTO veiculo
    FROM public.veiculos
    JOIN public.unidades ON veiculos.bloco = unidades.bloco and veiculos.unidade = unidades.num
   WHERE autenticacao = serialid;

  IF (veiculo.modelo ISNULL) THEN
    RETURN;
  END IF;

  INSERT INTO public.passagem_veiculo (condominio, bloco, andar, unidade, autenticacao, bloqueio, equipamento, localizacao_equipamento, leitor, localizacao_leitor, situacao_leitor, situacao_usuario, dsc_situacao, sentido, modelo, placa_letras, placa_numeros, cor, dispositivo)
  VALUES (veiculo.condominio, veiculo.bloco, veiculo.andar, veiculo.unidade, veiculo.autenticacao, veiculo.bloqueio, (info ->> 'equipamento')::int, (info ->> 'localizacao_equipamento'),
        (info ->> 'leitor')::int, (info ->> 'localizacao_leitor'), 'Autorizado', 'Autorizado', 'Autorizado', (info ->> 'sentido'), veiculo.modelo, veiculo.placa_letras, veiculo.placa_numeros, veiculo.cor, 'TAG');

  RETURN QUERY
  SELECT array_to_json(array_agg(row_to_json(veiculos_info))) AS info
  FROM (
         SELECT unidades.bloco, unidades.unidade, modelo, placa_letras || '-' || placa_numeros as placa, cor
         FROM public.veiculos
         JOIN public.unidades ON veiculos.bloco = unidades.bloco and veiculos.unidade = unidades.num
         WHERE autenticacao = serialid
       ) AS veiculos_info;

END;
$$;

