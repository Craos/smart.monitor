create function primeironome(nome character varying)
  returns character varying
language plpgsql
as $$
BEGIN
  IF (position(' ' IN nome) = 0)
  THEN
    RETURN nome;
  END IF;
  RETURN SUBSTRING(nome, 1, position(' ' IN nome) - 1);
END;
$$;

