create function atualizarpassagens(origem character varying)
  returns void
language plpgsql
as $$
DECLARE

BEGIN
  -- Inicia a conexao com o banco de dados central
  PERFORM dblink_connect(origem);

  /* Inicio do procedimento de upload das autorizações de acesso */
  DECLARE
    passagens RECORD;
  BEGIN
    FOR passagens IN SELECT * FROM passagem_pedestre LOOP
      PERFORM dblink_exec($_$
        INSERT INTO acesso.passagem_pedestre (filedate, timerg, uidins, num, condominio, bloco, andar, unidade, autenticacao, bloqueio, nome, equipamento, localizacao_equipamento, leitor, localizacao_leitor, situacao_leitor, situacao_usuario, dsc_situacao, sentido, tipo_de_cadastro, dispositivo)
        VALUES (
          '$_$ || passagens.filedate || $_$',
          '$_$ || passagens.timerg || $_$',
          '$_$ || passagens.uidins || $_$',
          '$_$ || passagens.num || $_$',
          '$_$ || passagens.condominio || $_$',
          '$_$ || passagens.bloco || $_$',
          '$_$ || passagens.andar || $_$',
          '$_$ || passagens.unidade || $_$',
          '$_$ || passagens.autenticacao || $_$',
          '$_$ || passagens.bloqueio || $_$',
          '$_$ || passagens.nome || $_$',
          '$_$ || passagens.equipamento || $_$',
          '$_$ || passagens.localizacao_equipamento || $_$',
          '$_$ || passagens.leitor || $_$',
          '$_$ || passagens.localizacao_leitor || $_$',
          '$_$ || passagens.situacao_leitor || $_$',
          '$_$ || passagens.situacao_usuario || $_$',
          '$_$ || passagens.dsc_situacao || $_$',
          '$_$ || passagens.sentido || $_$',
          '$_$ || passagens.tipo_de_cadastro || $_$',
          '$_$ || passagens.dispositivo || $_$'
        )
      $_$);

      DELETE
        FROM passagem_pedestre
       WHERE num = passagens.num;
    END LOOP;
  END;

  /* Final do procedimento de upload das autorizações de acesso */
  PERFORM dblink_disconnect();
  RETURN;
END;
$$;

