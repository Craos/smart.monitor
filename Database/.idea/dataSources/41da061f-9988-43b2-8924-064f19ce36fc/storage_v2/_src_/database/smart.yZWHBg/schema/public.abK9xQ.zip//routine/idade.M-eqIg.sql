create function idade(nascimento character varying)
  returns integer
language plpgsql
as $$
DECLARE

  quantos_anos    INTEGER;
  ano_atual       INTEGER;
  mes_atual       INTEGER;
  dia_atual       INTEGER;

  ano_aniversario INTEGER;
  mes_aniversario INTEGER;
  dia_aniversario INTEGER;
  data_nascimento DATE;
  
  numeroidade varchar;

BEGIN

  numeroidade := regexp_replace(nascimento , '[^0-9]*', '', 'g');
  IF (length(numeroidade) = 8) THEN
    data_nascimento := to_date(numeroidade, 'DDMMYYYY');
  ELSE
    data_nascimento = current_date;
  END IF;
  
  ano_atual := extract(YEAR FROM current_date);
  mes_atual := extract(MONTH FROM current_date);
  dia_atual := extract(DAY FROM current_date);

  ano_aniversario = extract(YEAR FROM data_nascimento);
  mes_aniversario = extract(MONTH FROM data_nascimento);
  dia_aniversario = extract(DAY FROM data_nascimento);

  quantos_anos = ano_atual - ano_aniversario;

  IF (mes_atual <= mes_aniversario)
  THEN
    quantos_anos = quantos_anos - 1;
  END IF;

  IF (quantos_anos < 0)
  THEN
    RETURN 0;
  ELSE
    RETURN quantos_anos;
  END IF;

END;
$$;

