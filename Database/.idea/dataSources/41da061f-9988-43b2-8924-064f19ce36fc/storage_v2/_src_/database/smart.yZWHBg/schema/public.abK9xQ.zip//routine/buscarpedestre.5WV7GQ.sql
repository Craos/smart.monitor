create function buscarpedestre(info json)
  returns SETOF json
language plpgsql
as $$
DECLARE
  usuario RECORD;
  serialid varchar;
  idade_minima varchar;
  situacao_leitor varchar;
  situacao_usuario varchar;
  dsc_situacao varchar;
BEGIN

  serialid := RIGHT(upper((info->>'serial')), 5);
  idade_minima := (info->>'idade_minima')::varchar;
  situacao_leitor := 'Autorizado';
  situacao_usuario := 'Autorizado';
  dsc_situacao := 'Autorizado';

  SELECT pedestre.condominio, unidades.bloco, unidades.andar, unidades.unidade, autenticacao, primeironome(nome) AS nome, bloqueio, idade(nascimento) as idade
    INTO usuario
    FROM public.pedestre
    JOIN public.unidades ON pedestre.bloco = unidades.bloco and pedestre.unidade = unidades.num
   WHERE autenticacao = serialid;

  IF (usuario.nome ISNULL) THEN
    RETURN;
  END IF;

  IF (char_length(idade_minima) > 0) THEN
      IF (usuario.idade < idade_minima::integer) THEN
        situacao_usuario := 'Idade não permitida';
      END IF;
  END IF;

  INSERT INTO public.passagem_pedestre (condominio, bloco, andar, unidade, autenticacao, bloqueio, equipamento, localizacao_equipamento, leitor, localizacao_leitor, situacao_leitor, situacao_usuario, dsc_situacao, sentido, nome, tipo_de_cadastro, dispositivo)
  VALUES (usuario.condominio, usuario.bloco, usuario.andar, usuario.unidade, usuario.autenticacao, usuario.bloqueio, (info ->> 'equipamento')::int, (info ->> 'localizacao_equipamento'), (info ->> 'leitor')::int, (info ->> 'localizacao_leitor'), situacao_leitor, situacao_usuario, dsc_situacao, (info ->> 'sentido'), usuario.nome, 'Morador', 'RFID');

  RETURN QUERY
  SELECT array_to_json(array_agg(row_to_json(usuario_info))) AS info
  FROM (
         SELECT
           pedestre.condominio, unidades.bloco, unidades.andar, unidades.unidade,
           primeironome(nome) AS nome,
           idade(nascimento)  as idade,
           foto1,
           CASE WHEN autenticacao = serialid
             THEN 1
           ELSE 0 END         AS usuario_identificado,
           autenticacao,
           bloqueio,
           situacao_usuario
         FROM public.pedestre
           JOIN public.unidades ON pedestre.bloco = unidades.bloco and pedestre.unidade = unidades.num
         WHERE usuario.bloco = unidades.bloco and usuario.unidade = unidades.unidade
       ) AS usuario_info;

END;
$$;

